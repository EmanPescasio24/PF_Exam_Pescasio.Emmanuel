﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RawSqlApi.Data;
using RawSqlApi.Models;

namespace RawSqlApi.Controllers
{
    [ApiController]
    [Route("api/orders")]
    public class OrdersControllers : ControllerBase
    {
        private readonly AppDbContext _context;
        public OrdersControllers(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IActionResult> GetOrders()
        {
            var sql = @"Select c.Name as CustomerName, o.Product, o.Price
                        From Customers c
                        INNER JOIN Orders o ON c.Id = o.CustomerId";

            var results = await _context.Database.SqlQueryRaw<CustomerOrderModel>(sql).ToListAsync();
            return Ok(results);
        }
        [HttpPost]
        public async Task<IActionResult> CreateOrder(CreateOrderRequest request)
        {
            var sql = @"INSERT INTO Orders (CustomerId, Product, Price)
                        VALUES ({0}, {1}, {2})";
            var rowsAffected = await _context.Database.ExecuteSqlRawAsync(sql, request.CustomerId, request.Product!, request.Price);

            return Ok(new
            {
                message = "Order created successfully",
                rowsAffected = rowsAffected
            });
        }
    }
}