import { Pokemon } from "../types";
// Tell TypeScript this component requires a valid Pokemon object
interface props {
    pokemon: Pokemon;
}
export default function PokemonCard({ pokemon }: props) {
    return (
        <div style={{ border: '2px solid #ccc', padding: '20px', borderRadius: '10px', textAlign: 'center' }}>
            <h2>#{pokemon.id} - {pokemon.name.toUpperCase()}</h2>
            <img src={pokemon.imageURL} alt={pokemon.name} width="150" />
            <p>Height: {pokemon.height}</p>
            <p>Weight: {pokemon.weight}</p> 
        </div>
    );
}