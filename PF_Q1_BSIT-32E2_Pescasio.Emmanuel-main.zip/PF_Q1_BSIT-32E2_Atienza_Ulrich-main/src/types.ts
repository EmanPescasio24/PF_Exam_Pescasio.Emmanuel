export interface Pokemon {
    id: number;
    name: string;
    height: number;
    weight: number;
    imageURL: string;
}
// test
