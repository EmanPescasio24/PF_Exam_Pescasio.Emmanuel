import { useState } from 'react';
import PokemonCard from './components/PokemonCard';
import PokemonSelector from './components/PokemonSelector';
import { Pokemon } from './types';
export default function App() {
    const [selectedPokemon, setSelectedPokemon] = useState<Pokemon | null>(null);
    // this function is passed down the PokemonSelector
    // The child calls it with the selected name
    function handleSelect(name: string) {
      fetch(`https://pokeapi.co/api/v2/pokemon/${name}`)
        .then(res => res.json())
        .then(data  => {
          const clean: Pokemon = {
            id: data.id,
            name: data.name,
            height: data.height,
            weight: data.weight,
            imageURL: data.sprites.front_default
          }
          setSelectedPokemon(clean);
        });
      }
      return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem' }}>
          <h1>Pokemon Explorer</h1>
          {/* Pass the function down as a prop */}
          <PokemonSelector onSelect={handleSelect} />
          {/* Conditionally render the card once we have data */}
          {selectedPokemon && <PokemonCard pokemon={selectedPokemon} />}
        </div>
      );
}